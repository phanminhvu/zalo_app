// Recommend store it into your db
const listCategoriesDummy = [
  {
    id: 1,
    iconCate: "icon-clothing",
    nameCate: "Hàng hiệu\ngiảm giá",
  },
  {
    id: 2,
    iconCate: "icon-accessories",
    nameCate: "Điện thoại\nPhụ kiện",
  },
  {
    id: 3,
    iconCate: "icon-phone",
    nameCate: "Sản phẩm\ngiảm giá",
  },
  {
    id: 4,
    iconCate: "icon-sale",
    nameCate: "Tech Zone-\nĐiện tử",
  },
  {
    id: 5,
    iconCate: "icon-deal-hot",
    nameCate: "Sản phẩm\ngiảm giá",
  },
  {
    id: 6,
    iconCate: "icon-techzone-fire",
    nameCate: "Tech Zone-\nĐiện tử",
  },
  {
    id: 7,
    iconCate: "icon-clothing",
    nameCate: "Sản phẩm\ngiảm giá",
  },
  {
    id: 8,
    iconCate: "icon-5.5",
    nameCate: "Nội thất\nsang trọng",
  },
];

export default listCategoriesDummy;
