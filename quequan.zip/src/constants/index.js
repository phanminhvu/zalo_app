// eslint-disable-next-line import/prefer-default-export
export const DEFAULT_OA_ID = "4318657068771012646";
