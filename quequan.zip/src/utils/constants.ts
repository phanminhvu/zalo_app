export const noImage = "https://vbphub.com/wp-content/uploads/2024/09/noimage.jpg";
export const GOOGLE_MAPS_API_KEY = "AIzaSyDTqCD9BHWsHyFV55REq8KmpNCMgorfP-s";
export const VIET_MAP_KEY = "2bc02708287581281a69ebb06e5d818770cc18629f57a043";
export const ZALO_OA_ID = "755177818804311101";
export const statusArray = [
    {
        key: "processing",
        label: "Đang xử lý"
    },{
        key: "completed",
        label: "Hoàn thành"
    },{
        key: "shipping",
        label: "Đang giao hàng"
    },{
        key: "closed",
        label: "Đã huỷ"
    },{
        key: "confirmed",
        label: "Đã xác nhận"
    },{
        key: "looking_for_driver",
        label: "Đang tìm tài xế "
    }
]
